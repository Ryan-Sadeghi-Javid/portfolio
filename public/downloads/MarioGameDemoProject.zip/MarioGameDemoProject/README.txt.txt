# Mario Physics Platformer Game

A Java-based Mario-style platformer built with a custom physics engine for my final high school CS project.

## 🎮 How to Play
1. Make sure you have Java 17+ installed
2. Install the JavaFX SDK (https://gluonhq.com/products/javafx/)
3. Update the path in `run.bat` to match your JavaFX installation
4. Double-click `run.bat`

## 🛠 How to Modify
- Edit levels in the `Level1/`, `Level2/`, etc. folders
- Modify Java code in `src/ICS4UProject/`
- Recompile using:
```bash
javac --module-path "path-to-javafx/lib" --add-modules javafx.controls,javafx.fxml,javafx.media -d out src/**/*.java

Happy Hacking!